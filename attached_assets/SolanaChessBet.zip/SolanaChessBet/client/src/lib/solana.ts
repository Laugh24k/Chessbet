import { Connection, PublicKey, SystemProgram, Transaction, LAMPORTS_PER_SOL } from '@solana/web3.js';

// Solana Devnet configuration
export const SOLANA_NETWORK = 'devnet';
export const connection = new Connection('https://api.devnet.solana.com', 'confirmed');

// Platform wallet address (for receiving deposits in escrow)
export const PLATFORM_WALLET = new PublicKey('7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU');

export interface TransactionResult {
  signature: string;
  success: boolean;
  error?: string;
}

export async function sendSolTransaction(
  fromPublicKey: PublicKey,
  toPublicKey: PublicKey,
  amount: number,
  walletAdapter: any
): Promise<TransactionResult> {
  try {
    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: fromPublicKey,
        toPubkey: toPublicKey,
        lamports: amount * LAMPORTS_PER_SOL,
      })
    );

    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = fromPublicKey;

    const signedTransaction = await walletAdapter.signTransaction(transaction);
    const signature = await connection.sendRawTransaction(signedTransaction.serialize());

    await connection.confirmTransaction(signature, 'confirmed');

    return {
      signature,
      success: true,
    };
  } catch (error) {
    console.error('Transaction failed:', error);
    return {
      signature: '',
      success: false,
      error: error instanceof Error ? error.message : 'Transaction failed',
    };
  }
}

export async function getWalletBalance(publicKey: PublicKey): Promise<number> {
  try {
    const balance = await connection.getBalance(publicKey);
    return balance / LAMPORTS_PER_SOL;
  } catch (error) {
    console.error('Failed to get wallet balance:', error);
    return 0;
  }
}

export function formatSolAmount(amount: number, decimals: number = 4): string {
  return amount.toFixed(decimals);
}

export function parseSolAmount(amountString: string): number {
  return parseFloat(amountString) || 0;
}
