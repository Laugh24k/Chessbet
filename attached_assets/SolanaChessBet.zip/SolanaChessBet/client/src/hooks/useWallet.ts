import { useState, useEffect, useCallback } from 'react';
import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';

// Solana Devnet connection
const connection = new Connection('https://api.devnet.solana.com', 'confirmed');

interface SolanaWindow extends Window {
  solana?: {
    isPhantom?: boolean;
    connect: () => Promise<{ publicKey: PublicKey }>;
    disconnect: () => Promise<void>;
    on: (event: string, callback: Function) => void;
    request: (params: any) => Promise<any>;
  };
}

declare const window: SolanaWindow;

export function useWallet() {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [publicKey, setPublicKey] = useState<string | null>(null);
  const [balance, setBalance] = useState(0);

  const connect = useCallback(async () => {
    if (!window.solana) {
      throw new Error('Phantom wallet not found! Please install Phantom wallet.');
    }

    try {
      setConnecting(true);
      const response = await window.solana.connect();
      const pubKey = response.publicKey.toString();
      
      setPublicKey(pubKey);
      setConnected(true);
      
      // Fetch balance
      const balanceResponse = await connection.getBalance(response.publicKey);
      setBalance(balanceResponse / LAMPORTS_PER_SOL);
      
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    } finally {
      setConnecting(false);
    }
  }, []);

  const disconnect = useCallback(async () => {
    if (window.solana) {
      try {
        await window.solana.disconnect();
      } catch (error) {
        console.error('Failed to disconnect wallet:', error);
      }
    }
    
    setConnected(false);
    setPublicKey(null);
    setBalance(0);
  }, []);

  // Check if wallet is already connected on load
  useEffect(() => {
    const checkConnection = async () => {
      if (window.solana && window.solana.isPhantom) {
        try {
          const response = await window.solana.connect({ onlyIfTrusted: true });
          if (response.publicKey) {
            const pubKey = response.publicKey.toString();
            setPublicKey(pubKey);
            setConnected(true);
            
            // Fetch balance
            const balanceResponse = await connection.getBalance(response.publicKey);
            setBalance(balanceResponse / LAMPORTS_PER_SOL);
          }
        } catch (error) {
          // Wallet not connected or user rejected
          console.log('Wallet not connected or user rejected');
        }
      }
    };

    checkConnection();

    // Listen for wallet events
    if (window.solana) {
      window.solana.on('connect', (publicKey: PublicKey) => {
        console.log('Wallet connected:', publicKey.toString());
        setConnected(true);
        setPublicKey(publicKey.toString());
      });

      window.solana.on('disconnect', () => {
        console.log('Wallet disconnected');
        setConnected(false);
        setPublicKey(null);
        setBalance(0);
      });
    }
  }, []);

  // Update balance periodically
  useEffect(() => {
    if (connected && publicKey) {
      const updateBalance = async () => {
        try {
          const balanceResponse = await connection.getBalance(new PublicKey(publicKey));
          setBalance(balanceResponse / LAMPORTS_PER_SOL);
        } catch (error) {
          console.error('Failed to update balance:', error);
        }
      };

      const interval = setInterval(updateBalance, 10000); // Update every 10 seconds
      return () => clearInterval(interval);
    }
  }, [connected, publicKey]);

  return {
    connected,
    connecting,
    publicKey,
    balance,
    connect,
    disconnect,
  };
}
