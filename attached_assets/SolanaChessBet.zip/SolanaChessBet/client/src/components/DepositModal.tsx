import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useWalletContext } from '@/components/WalletProvider';
import { sendSolTransaction, PLATFORM_WALLET } from '@/lib/solana';
import { PublicKey } from '@solana/web3.js';
import { Plus, Info } from 'lucide-react';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: number | null;
  currentBalance: string;
}

export default function DepositModal({ isOpen, onClose, userId, currentBalance }: DepositModalProps) {
  const [amount, setAmount] = useState('');
  const { toast } = useToast();
  const { publicKey } = useWalletContext();

  const depositMutation = useMutation({
    mutationFn: async (transactionData: any) => {
      if (!publicKey || !(window as any).solana) {
        throw new Error('Wallet not connected');
      }

      // First, send the SOL transaction to the platform wallet
      const userPublicKey = new PublicKey(publicKey);
      const depositAmount = parseFloat(transactionData.amount);
      
      try {
        const txResult = await sendSolTransaction(
          userPublicKey,
          PLATFORM_WALLET,
          depositAmount,
          (window as any).solana
        );

        if (!txResult.success) {
          throw new Error(txResult.error || 'Transaction failed');
        }

        // If transaction succeeded, record it in our system
        const response = await apiRequest('POST', '/api/transactions', {
          ...transactionData,
          txHash: txResult.signature,
          status: 'completed'
        });
        
        return { ...response.json(), txHash: txResult.signature };
      } catch (error) {
        throw new Error(error instanceof Error ? error.message : 'Transaction failed');
      }
    },
    onSuccess: (result) => {
      toast({
        title: 'Deposit Successful',
        description: `${amount} SOL has been deposited. Transaction: ${result.txHash?.slice(0, 8)}...`,
      });
      
      // Invalidate user data to refresh balance
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      
      setAmount('');
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: 'Deposit Failed',
        description: error.message || 'Failed to process deposit. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const handleDeposit = () => {
    if (!userId) {
      toast({
        title: 'Error',
        description: 'Please connect your wallet first.',
        variant: 'destructive',
      });
      return;
    }

    const depositAmount = parseFloat(amount);
    
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount greater than 0.',
        variant: 'destructive',
      });
      return;
    }

    if (depositAmount < 0.01) {
      toast({
        title: 'Minimum Deposit',
        description: 'Minimum deposit amount is 0.01 SOL.',
        variant: 'destructive',
      });
      return;
    }

    const transactionData = {
      userId,
      type: 'deposit',
      amount: depositAmount.toString(),
      status: 'pending',
    };

    depositMutation.mutate(transactionData);
  };

  const handleClose = () => {
    if (!depositMutation.isPending) {
      setAmount('');
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md glass-effect border-accent-purple/30">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-accent-purple">
            <Plus className="h-5 w-5" />
            Deposit SOL
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-gray-300">
              Amount (SOL)
            </Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-dark-navy/50 border-accent-purple/30 text-white placeholder-gray-500 focus:border-accent-purple"
              step="0.01"
              min="0.01"
              disabled={depositMutation.isPending}
            />
          </div>

          <div className="flex items-start gap-2 p-3 bg-blue-600/10 border border-blue-500/20 rounded-lg">
            <Info className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-blue-300">
              <p className="font-medium mb-1">Deposit Information:</p>
              <ul className="space-y-1">
                <li>• Minimum deposit: 0.01 SOL</li>
                <li>• Funds will be available immediately</li>
                <li>• Current gaming balance: {currentBalance} SOL</li>
              </ul>
            </div>
          </div>

          <Button
            onClick={handleDeposit}
            disabled={depositMutation.isPending || !amount || parseFloat(amount) < 0.01}
            className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:shadow-lg hover:shadow-green-500/25"
          >
            {depositMutation.isPending ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Processing Deposit...
              </div>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Deposit {amount || '0.00'} SOL
              </>
            )}
          </Button>

          <p className="text-xs text-gray-400 text-center">
            This will send SOL from your wallet to the platform's escrow wallet for gaming.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
