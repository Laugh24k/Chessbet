import { useState, useEffect, useCallback } from 'react';
import { Chess, Square, PieceSymbol, Color, Move } from 'chess.js';

interface ChessBoardProps {
  chess: Chess;
  playerColor: Color;
  isPlayerTurn: boolean;
  onMove: (move: Move) => void;
  lastMove?: Move | null;
}

const pieceSymbols: Record<string, string> = {
  'wp': '♙', 'wr': '♖', 'wn': '♘', 'wb': '♗', 'wq': '♕', 'wk': '♔',
  'bp': '♟', 'br': '♜', 'bn': '♞', 'bb': '♝', 'bq': '♛', 'bk': '♚',
};

export default function ChessBoard({ chess, playerColor, isPlayerTurn, onMove, lastMove }: ChessBoardProps) {
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [possibleMoves, setPossibleMoves] = useState<Square[]>([]);
  const [boardState, setBoardState] = useState(chess.board());

  useEffect(() => {
    setBoardState(chess.board());
    setSelectedSquare(null);
    setPossibleMoves([]);
  }, [chess]);

  const getSquareColor = useCallback((row: number, col: number): string => {
    return (row + col) % 2 === 0 ? 'light' : 'dark';
  }, []);

  const getSquareNotation = useCallback((row: number, col: number): Square => {
    const file = String.fromCharCode(97 + col); // a-h
    const rank = (8 - row).toString(); // 8-1
    return `${file}${rank}` as Square;
  }, []);

  const isSquareSelected = useCallback((row: number, col: number): boolean => {
    if (!selectedSquare) return false;
    return selectedSquare === getSquareNotation(row, col);
  }, [selectedSquare, getSquareNotation]);

  const isSquarePossibleMove = useCallback((row: number, col: number): boolean => {
    const square = getSquareNotation(row, col);
    return possibleMoves.includes(square);
  }, [possibleMoves, getSquareNotation]);

  const isSquareLastMove = useCallback((row: number, col: number): boolean => {
    if (!lastMove) return false;
    const square = getSquareNotation(row, col);
    return square === lastMove.from || square === lastMove.to;
  }, [lastMove, getSquareNotation]);

  const handleSquareClick = useCallback((row: number, col: number) => {
    if (!isPlayerTurn) return;

    const square = getSquareNotation(row, col);
    const piece = chess.get(square);

    if (selectedSquare) {
      // Try to make a move
      try {
        const move = chess.move({
          from: selectedSquare,
          to: square,
          promotion: 'q', // Always promote to queen for simplicity
        });

        if (move) {
          onMove(move);
          setSelectedSquare(null);
          setPossibleMoves([]);
          return;
        }
      } catch (error) {
        // Invalid move, continue to piece selection logic
      }

      // If move failed, try selecting new piece
      setSelectedSquare(null);
      setPossibleMoves([]);
    }

    // Select piece if it belongs to the current player
    if (piece && piece.color === playerColor) {
      setSelectedSquare(square);
      const moves = chess.moves({ square, verbose: true });
      setPossibleMoves(moves.map(move => move.to));
    } else {
      setSelectedSquare(null);
      setPossibleMoves([]);
    }
  }, [chess, selectedSquare, isPlayerTurn, playerColor, onMove, getSquareNotation]);

  const renderSquare = useCallback((row: number, col: number) => {
    const piece = boardState[row][col];
    const squareColor = getSquareColor(row, col);
    const isSelected = isSquareSelected(row, col);
    const isPossibleMove = isSquarePossibleMove(row, col);
    const isLastMove = isSquareLastMove(row, col);

    let squareClasses = `chess-square ${squareColor}`;
    if (isSelected) squareClasses += ' selected';
    if (isPossibleMove) squareClasses += ' possible-move';
    if (isLastMove) squareClasses += ' last-move';

    const pieceSymbol = piece ? pieceSymbols[`${piece.color}${piece.type}`] : '';

    return (
      <div
        key={`${row}-${col}`}
        className={squareClasses}
        onClick={() => handleSquareClick(row, col)}
      >
        <span className="chess-piece">{pieceSymbol}</span>
      </div>
    );
  }, [boardState, getSquareColor, isSquareSelected, isSquarePossibleMove, isSquareLastMove, handleSquareClick]);

  const renderBoard = () => {
    const squares = [];
    
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        squares.push(renderSquare(row, col));
      }
    }

    return squares;
  };

  return (
    <div className="bg-dark-purple/50 backdrop-blur-xl rounded-2xl p-8 border border-accent-purple/20">
      <div className="grid grid-cols-8 gap-0 border-2 border-accent-purple/30 rounded-xl overflow-hidden shadow-2xl">
        {renderBoard()}
      </div>
      
      {/* Game status */}
      <div className="mt-4 text-center">
        {chess.isGameOver() ? (
          <div className="text-lg font-semibold">
            {chess.isCheckmate() ? (
              <span className="text-red-400">
                Checkmate! {chess.turn() === 'w' ? 'Black' : 'White'} wins!
              </span>
            ) : chess.isStalemate() ? (
              <span className="text-yellow-400">Stalemate! It's a draw!</span>
            ) : chess.isDraw() ? (
              <span className="text-yellow-400">Draw!</span>
            ) : (
              <span className="text-gray-400">Game Over</span>
            )}
          </div>
        ) : (
          <div className="text-sm text-gray-400">
            {chess.turn() === playerColor ? (
              isPlayerTurn ? (
                <span className="text-green-400">Your turn</span>
              ) : (
                <span className="text-yellow-400">Waiting for your move...</span>
              )
            ) : (
              <span className="text-gray-400">Opponent's turn</span>
            )}
            {chess.isCheck() && (
              <span className="text-red-400 ml-2">Check!</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
