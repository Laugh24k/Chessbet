import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Search, Users, Trophy, Clock } from 'lucide-react';
import { Game, User } from '@shared/schema';

interface GameLobbyProps {
  currentUser: User | null;
  onJoinGame: (gameId: number) => void;
  onCreateGame: () => void;
}

export default function GameLobby({ currentUser, onJoinGame, onCreateGame }: GameLobbyProps) {
  const [selectedBetAmount, setSelectedBetAmount] = useState('0.10');
  const [timeControl, setTimeControl] = useState('10+0');

  const { data: waitingGames, isLoading } = useQuery({
    queryKey: ['/api/games/waiting'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const createGameMutation = useMutation({
    mutationFn: async (gameData: any) => {
      const response = await apiRequest('POST', '/api/games', gameData);
      return response.json();
    },
    onSuccess: (game) => {
      queryClient.invalidateQueries({ queryKey: ['/api/games/waiting'] });
      onJoinGame(game.id);
    },
  });

  const joinGameMutation = useMutation({
    mutationFn: async ({ gameId, userId }: { gameId: number; userId: number }) => {
      const response = await apiRequest('POST', `/api/games/${gameId}/join`, { userId });
      return response.json();
    },
    onSuccess: (game) => {
      queryClient.invalidateQueries({ queryKey: ['/api/games/waiting'] });
      onJoinGame(game.id);
    },
  });

  const handleCreateGame = () => {
    if (!currentUser) return;

    const gameData = {
      whitePlayerId: currentUser.id,
      betAmount: selectedBetAmount,
      potAmount: (parseFloat(selectedBetAmount) * 2).toString(),
      timeControl,
      gameState: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
    };

    createGameMutation.mutate(gameData);
  };

  const handleJoinGame = (gameId: number) => {
    if (!currentUser) return;
    joinGameMutation.mutate({ gameId, userId: currentUser.id });
  };

  const betAmountOptions = [
    { value: '0.01', label: '0.01 SOL' },
    { value: '0.05', label: '0.05 SOL' },
    { value: '0.10', label: '0.10 SOL' },
    { value: '0.25', label: '0.25 SOL' },
    { value: '0.50', label: '0.50 SOL' },
  ];

  const timeControlOptions = [
    { value: '5+3', label: '5+3 (Blitz)' },
    { value: '10+0', label: '10+0 (Rapid)' },
    { value: '30+0', label: '30+0 (Classical)' },
  ];

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center h-64">
        <Card className="glass-effect">
          <CardContent className="p-6 text-center">
            <Users className="h-12 w-12 text-accent-purple mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Connect Your Wallet</h3>
            <p className="text-gray-400">Please connect your Solana wallet to join games</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Create Game Section */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-accent-cyan">
            <Plus className="h-5 w-5" />
            Create New Game
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Bet Amount</label>
              <select
                value={selectedBetAmount}
                onChange={(e) => setSelectedBetAmount(e.target.value)}
                className="w-full bg-dark-navy/50 border border-accent-purple/30 rounded-xl px-4 py-3 text-white focus:border-accent-purple focus:outline-none"
              >
                {betAmountOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Time Control</label>
              <select
                value={timeControl}
                onChange={(e) => setTimeControl(e.target.value)}
                className="w-full bg-dark-navy/50 border border-accent-purple/30 rounded-xl px-4 py-3 text-white focus:border-accent-purple focus:outline-none"
              >
                {timeControlOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Required Balance:</span>
            <span className="font-bold text-accent-cyan">{selectedBetAmount} SOL</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Total Pot:</span>
            <span className="font-bold text-green-400">{(parseFloat(selectedBetAmount) * 2).toFixed(2)} SOL</span>
          </div>

          <Button
            onClick={handleCreateGame}
            disabled={createGameMutation.isPending || parseFloat(currentUser.gameBalance) < parseFloat(selectedBetAmount)}
            className="w-full bg-gradient-to-r from-accent-purple to-accent-cyan hover:shadow-lg hover:shadow-accent-purple/25"
          >
            {createGameMutation.isPending ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Creating Game...
              </div>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Create Game
              </>
            )}
          </Button>

          {parseFloat(currentUser.gameBalance) < parseFloat(selectedBetAmount) && (
            <p className="text-sm text-red-400 text-center">
              Insufficient balance. Please deposit more SOL.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Waiting Games Section */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-accent-purple">
            <Search className="h-5 w-5" />
            Available Games
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-dark-navy/30 rounded-lg">
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-10 w-20" />
                </div>
              ))}
            </div>
          ) : waitingGames && waitingGames.length > 0 ? (
            <div className="space-y-3">
              {waitingGames.map((game: Game) => (
                <div
                  key={game.id}
                  className="flex items-center justify-between p-4 bg-dark-navy/30 rounded-lg border border-accent-purple/10 hover:border-accent-purple/30 transition-colors"
                >
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <Badge variant="secondary" className="bg-green-600/20 text-green-400">
                        <Trophy className="h-3 w-3 mr-1" />
                        {game.betAmount} SOL
                      </Badge>
                      <Badge variant="outline" className="border-accent-purple/30 text-accent-purple">
                        <Clock className="h-3 w-3 mr-1" />
                        {game.timeControl}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-400">
                      Pot: <span className="text-accent-cyan font-semibold">{game.potAmount} SOL</span>
                    </div>
                  </div>
                  
                  <Button
                    onClick={() => handleJoinGame(game.id)}
                    disabled={joinGameMutation.isPending || 
                             parseFloat(currentUser.gameBalance) < parseFloat(game.betAmount) ||
                             game.whitePlayerId === currentUser.id}
                    variant="outline"
                    className="border-accent-cyan/30 text-accent-cyan hover:bg-accent-cyan/10"
                  >
                    {joinGameMutation.isPending ? (
                      <div className="w-4 h-4 border-2 border-accent-cyan/30 border-t-accent-cyan rounded-full animate-spin" />
                    ) : game.whitePlayerId === currentUser.id ? (
                      'Your Game'
                    ) : (
                      'Join'
                    )}
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-300 mb-2">No Games Available</h3>
              <p className="text-gray-500">Create a new game to start playing!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
