import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { sendSolTransaction, PLATFORM_WALLET } from '@/lib/solana';
import { PublicKey } from '@solana/web3.js';
import { Minus, Wallet, Info } from 'lucide-react';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: number | null;
  currentBalance: string;
  walletAddress: string | null;
}

export default function WithdrawModal({ 
  isOpen, 
  onClose, 
  userId, 
  currentBalance, 
  walletAddress 
}: WithdrawModalProps) {
  const [amount, setAmount] = useState('');
  const { toast } = useToast();

  const withdrawMutation = useMutation({
    mutationFn: async (transactionData: any) => {
      const response = await apiRequest('POST', '/api/transactions', transactionData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Withdrawal Successful',
        description: `${amount} SOL has been withdrawn from your gaming balance.`,
      });
      
      // Invalidate user data to refresh balance
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      
      setAmount('');
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: 'Withdrawal Failed',
        description: error.message || 'Failed to process withdrawal. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const handleWithdraw = () => {
    if (!userId) {
      toast({
        title: 'Error',
        description: 'Please connect your wallet first.',
        variant: 'destructive',
      });
      return;
    }

    if (!walletAddress) {
      toast({
        title: 'Error',
        description: 'Wallet address not found.',
        variant: 'destructive',
      });
      return;
    }

    const withdrawAmount = parseFloat(amount);
    const balance = parseFloat(currentBalance);
    
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount greater than 0.',
        variant: 'destructive',
      });
      return;
    }

    if (withdrawAmount > balance) {
      toast({
        title: 'Insufficient Balance',
        description: 'You cannot withdraw more than your current balance.',
        variant: 'destructive',
      });
      return;
    }

    if (withdrawAmount < 0.001) {
      toast({
        title: 'Minimum Withdrawal',
        description: 'Minimum withdrawal amount is 0.001 SOL.',
        variant: 'destructive',
      });
      return;
    }

    const transactionData = {
      userId,
      type: 'withdraw',
      amount: withdrawAmount.toString(),
      status: 'pending',
    };

    withdrawMutation.mutate(transactionData);
  };

  const handleClose = () => {
    if (!withdrawMutation.isPending) {
      setAmount('');
      onClose();
    }
  };

  const maxWithdrawable = parseFloat(currentBalance);
  const withdrawalFee = 0.001;
  const actualWithdrawAmount = parseFloat(amount) || 0;
  const netAmount = Math.max(0, actualWithdrawAmount - withdrawalFee);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md glass-effect border-accent-purple/30">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-orange-400">
            <Minus className="h-5 w-5" />
            Withdraw SOL
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-gray-300">
              Amount (SOL)
            </Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-dark-navy/50 border-accent-purple/30 text-white placeholder-gray-500 focus:border-accent-purple"
              step="0.001"
              min="0.001"
              max={maxWithdrawable}
              disabled={withdrawMutation.isPending}
            />
          </div>

          <div className="space-y-2 text-xs text-gray-400">
            <div className="flex items-center gap-2">
              <Wallet className="h-3 w-3" />
              <span>Available: {currentBalance} SOL</span>
            </div>
            <div className="flex justify-between">
              <span>Withdrawal amount:</span>
              <span className="text-white">{actualWithdrawAmount.toFixed(3)} SOL</span>
            </div>
            <div className="flex justify-between">
              <span>Network fee:</span>
              <span className="text-orange-400">-{withdrawalFee.toFixed(3)} SOL</span>
            </div>
            <hr className="border-accent-purple/20" />
            <div className="flex justify-between font-medium">
              <span>You will receive:</span>
              <span className="text-green-400">{netAmount.toFixed(3)} SOL</span>
            </div>
          </div>

          <div className="flex items-start gap-2 p-3 bg-orange-600/10 border border-orange-500/20 rounded-lg">
            <Info className="h-4 w-4 text-orange-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-orange-300">
              <p className="font-medium mb-1">Withdrawal Information:</p>
              <ul className="space-y-1">
                <li>• Minimum withdrawal: 0.001 SOL</li>
                <li>• Network fee: 0.001 SOL</li>
                <li>• Funds will be sent to your connected wallet</li>
              </ul>
            </div>
          </div>

          {walletAddress && (
            <div className="p-2 bg-dark-navy/50 rounded border border-accent-purple/20">
              <div className="text-xs text-gray-400 mb-1">Withdraw to:</div>
              <div className="text-xs font-mono text-white break-all">
                {walletAddress}
              </div>
            </div>
          )}

          <Button
            onClick={handleWithdraw}
            disabled={
              withdrawMutation.isPending || 
              !amount || 
              parseFloat(amount) < 0.001 || 
              parseFloat(amount) > maxWithdrawable
            }
            className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:shadow-lg hover:shadow-orange-500/25"
          >
            {withdrawMutation.isPending ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Processing Withdrawal...
              </div>
            ) : (
              <>
                <Minus className="h-4 w-4 mr-2" />
                Withdraw {amount || '0.00'} SOL
              </>
            )}
          </Button>

          <p className="text-xs text-gray-400 text-center">
            The withdrawal fee goes to covering Solana network transaction costs.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
