import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Chess, Color } from 'chess.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useWalletContext } from '@/components/WalletProvider';
import { useWebSocket } from '@/hooks/useWebSocket';
import { apiRequest, queryClient } from '@/lib/queryClient';
import ChessBoard from '@/components/ChessBoard';
import GameLobby from '@/components/GameLobby';
import DepositModal from '@/components/DepositModal';
import WithdrawModal from '@/components/WithdrawModal';
import { 
  Sword, 
  Wallet, 
  Plus, 
  Minus, 
  Users, 
  History, 
  Trophy, 
  Coins,
  Flag,
  Handshake,
  MessageSquare,
  Clock,
  Zap
} from 'lucide-react';
import { User, Game } from '@shared/schema';

export default function ChessGamePage() {
  const { connected, connecting, publicKey, balance, connect, disconnect } = useWalletContext();
  const { toast } = useToast();
  
  // Modals state
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  
  // Game state
  const [currentGame, setCurrentGame] = useState<Game | null>(null);
  const [chess] = useState(() => new Chess());
  const [playerColor, setPlayerColor] = useState<Color>('w');
  const [isPlayerTurn, setIsPlayerTurn] = useState(false);
  const [gameStatus, setGameStatus] = useState<'lobby' | 'playing' | 'completed'>('lobby');
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  const [lastMove, setLastMove] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState({ white: 600, black: 600 });
  
  // User data
  const { data: currentUser } = useQuery({
    queryKey: ['/api/users', publicKey],
    queryFn: async () => {
      if (!publicKey) return null;
      try {
        const response = await fetch(`/api/users/${publicKey}`, { credentials: 'include' });
        if (response.status === 404) {
          // Create new user
          const createResponse = await apiRequest('POST', '/api/users', {
            walletAddress: publicKey,
            username: `Player_${publicKey.slice(-6)}`,
          });
          return createResponse.json();
        }
        return response.json();
      } catch (error) {
        return null;
      }
    },
    enabled: !!publicKey,
  });

  // WebSocket connection for real-time game updates
  const { isConnected: wsConnected, sendMessage } = useWebSocket({
    onMessage: (data) => {
      handleWebSocketMessage(data);
    },
    onOpen: () => {
      console.log('WebSocket connected');
    },
    onClose: () => {
      console.log('WebSocket disconnected');
    },
  });

  const handleWebSocketMessage = (data: any) => {
    const { type } = data;
    
    switch (type) {
      case 'game_state':
        if (data.fen) {
          chess.load(data.fen);
          setMoveHistory(data.moveHistory || []);
          setIsPlayerTurn(
            (data.turn === 'w' && playerColor === 'w') ||
            (data.turn === 'b' && playerColor === 'b')
          );
        }
        break;
        
      case 'move_made':
        if (data.fen) {
          chess.load(data.fen);
          setMoveHistory(chess.history());
          setLastMove(data.move);
          setIsPlayerTurn(
            (data.turn === 'w' && playerColor === 'w') ||
            (data.turn === 'b' && playerColor === 'b')
          );
          
          if (data.gameResult) {
            handleGameEnd(data.gameResult);
          }
        }
        break;
        
      case 'game_ready':
        setGameStatus('playing');
        toast({
          title: 'Game Started!',
          description: 'Your chess match has begun. Good luck!',
        });
        break;
        
      case 'error':
        toast({
          title: 'Game Error',
          description: data.message,
          variant: 'destructive',
        });
        break;
    }
  };

  const handleGameEnd = (result: string) => {
    setGameStatus('completed');
    let message = '';
    
    if (result === 'draw') {
      message = 'Game ended in a draw!';
    } else if (
      (result === 'white' && playerColor === 'w') ||
      (result === 'black' && playerColor === 'b')
    ) {
      message = 'Congratulations! You won!';
    } else {
      message = 'Game over. Better luck next time!';
    }
    
    toast({
      title: 'Game Finished',
      description: message,
    });
    
    // Refresh user data to update balance and stats
    queryClient.invalidateQueries({ queryKey: ['/api/users'] });
  };

  const handleJoinGame = async (gameId: number) => {
    try {
      const response = await fetch(`/api/games/${gameId}`, { credentials: 'include' });
      const game = await response.json();
      
      setCurrentGame(game);
      setGameStatus('playing');
      
      // Determine player color
      const isWhitePlayer = game.whitePlayerId === currentUser?.id;
      setPlayerColor(isWhitePlayer ? 'w' : 'b');
      
      // Load game state
      chess.load(game.gameState);
      setMoveHistory(game.moveHistory || []);
      
      // Join WebSocket room
      if (wsConnected && currentUser) {
        sendMessage({
          type: 'join_game',
          gameId: game.id,
          userId: currentUser.id,
        });
      }
      
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to join game',
        variant: 'destructive',
      });
    }
  };

  const handleMakeMove = (move: any) => {
    if (!currentGame || !currentUser || !wsConnected) return;
    
    sendMessage({
      type: 'make_move',
      gameId: currentGame.id,
      userId: currentUser.id,
      data: move,
    });
  };

  const handleResign = () => {
    if (!currentGame || !currentUser) return;
    
    if (!confirm(`Are you sure you want to resign? You will lose your bet of ${currentGame.betAmount} SOL.`)) return;
    
    // Send resign message via WebSocket
    if (wsConnected) {
      sendMessage({
        type: 'resign_game',
        gameId: currentGame.id,
        userId: currentUser.id,
      });
    }
    
    toast({
      title: 'Game Resigned',
      description: `You have resigned from the game. Your opponent wins ${currentGame.potAmount} SOL.`,
    });
    
    setGameStatus('lobby');
    setCurrentGame(null);
    
    // Refresh user data to update balance
    queryClient.invalidateQueries({ queryKey: ['/api/users'] });
  };

  const handleOfferDraw = () => {
    toast({
      title: 'Draw Offered',
      description: 'Draw offer sent to your opponent.',
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const renderMoveHistory = () => {
    const moves = [];
    for (let i = 0; i < moveHistory.length; i += 2) {
      const moveNumber = Math.floor(i / 2) + 1;
      const whiteMove = moveHistory[i];
      const blackMove = moveHistory[i + 1];
      
      moves.push(
        <div key={moveNumber} className="flex justify-between text-sm font-mono">
          <span className="text-gray-400">{moveNumber}.</span>
          <span className="text-white">{whiteMove}</span>
          <span className="text-gray-300">{blackMove || '...'}</span>
        </div>
      );
    }
    return moves;
  };

  // Main render
  return (
    <div className="flex h-screen overflow-hidden bg-gradient-to-br from-slate-900 to-indigo-950">
      {/* Sidebar */}
      <div className="w-80 bg-slate-800/50 backdrop-blur-xl border-r border-purple-500/20 flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-purple-500/20">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-xl flex items-center justify-center">
              <Sword className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold neon-glow text-purple-400">ChessWager</h1>
              <p className="text-xs text-gray-400">Solana Chess Betting</p>
            </div>
          </div>
          
          {/* Wallet Connection */}
          <div className="space-y-4">
            {!connected ? (
              <Button 
                onClick={connect}
                disabled={connecting}
                className="w-full bg-gradient-to-r from-purple-500 to-cyan-500 hover:shadow-lg hover:shadow-purple-500/25"
              >
                {connecting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Connecting...
                  </div>
                ) : (
                  <>
                    <Wallet className="w-4 h-4 mr-2" />
                    Connect Solana Wallet
                  </>
                )}
              </Button>
            ) : (
              <Card className="glass-effect">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-400 rounded-full connection-pulse" />
                      <span className="text-sm font-medium">Connected</span>
                    </div>
                    <Button 
                      onClick={disconnect}
                      variant="ghost" 
                      size="sm"
                      className="text-gray-400 hover:text-red-400 p-1 h-auto"
                      title="Disconnect Wallet"
                    >
                      <Zap className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="text-xs text-gray-400 mb-1">Wallet Address</div>
                  <div className="text-xs font-mono bg-slate-900/50 rounded px-2 py-1 mb-3 break-all">
                    {publicKey}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Balance</span>
                    <span className="font-bold text-cyan-400">{balance.toFixed(3)} SOL</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
        
        {/* Balance and Actions */}
        {connected && currentUser && (
          <div className="p-6 border-b border-purple-500/20">
            <Card className="glass-effect mb-4">
              <CardContent className="p-4 text-center">
                <div className="text-sm text-gray-400 mb-1">Gaming Balance</div>
                <div className="text-2xl font-bold text-white mb-3">
                  {parseFloat(currentUser.gameBalance).toFixed(3)} SOL
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    onClick={() => setShowDepositModal(true)}
                    variant="outline"
                    size="sm"
                    className="border-green-500/30 text-green-400 hover:bg-green-500/20"
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    Deposit
                  </Button>
                  <Button
                    onClick={() => setShowWithdrawModal(true)}
                    variant="outline"
                    size="sm"
                    className="border-orange-500/30 text-orange-400 hover:bg-orange-500/20"
                  >
                    <Minus className="w-3 h-3 mr-1" />
                    Withdraw
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* User Stats */}
            <div className="grid grid-cols-2 gap-3">
              <Card className="bg-slate-900/50">
                <CardContent className="p-3 text-center">
                  <div className="text-lg font-bold text-green-400">{currentUser.wins}</div>
                  <div className="text-xs text-gray-400">Wins</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-900/50">
                <CardContent className="p-3 text-center">
                  <div className="text-lg font-bold text-red-400">{currentUser.losses}</div>
                  <div className="text-xs text-gray-400">Losses</div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
        
        {/* Navigation */}
        <div className="flex-1 p-6">
          <nav className="space-y-2">
            <Button
              variant={gameStatus === 'lobby' ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setGameStatus('lobby')}
            >
              <Users className="w-4 h-4 mr-3" />
              Game Lobby
            </Button>
            <Button variant="ghost" className="w-full justify-start" disabled>
              <History className="w-4 h-4 mr-3" />
              Game History
            </Button>
          </nav>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        {gameStatus === 'playing' && currentGame && (
          <div className="h-16 bg-slate-800/30 backdrop-blur-xl border-b border-purple-500/20 flex items-center justify-between px-6">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse" />
                <span className="text-sm font-medium">Live Game</span>
              </div>
              <div className="text-sm text-gray-400">
                vs <span className="text-white font-medium">Opponent</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm">
                <span className="text-gray-400">Pot:</span>
                <span className="font-bold text-cyan-400 ml-1">{currentGame.potAmount} SOL</span>
              </div>
              <div className="text-sm">
                <span className="text-gray-400">Time:</span>
                <span className="font-mono text-white ml-1">
                  {formatTime(playerColor === 'w' ? timeRemaining.white : timeRemaining.black)}
                </span>
              </div>
            </div>
          </div>
        )}
        
        {/* Game Area */}
        <div className="flex-1 flex">
          {gameStatus === 'lobby' ? (
            <div className="flex-1 p-8">
              <GameLobby
                currentUser={currentUser}
                onJoinGame={handleJoinGame}
                onCreateGame={() => {}} // Handled in GameLobby component
              />
            </div>
          ) : (
            <>
              {/* Chess Board */}
              <div className="flex-1 flex items-center justify-center p-8">
                <div className="space-y-6">
                  <ChessBoard
                    chess={chess}
                    playerColor={playerColor}
                    isPlayerTurn={isPlayerTurn}
                    onMove={handleMakeMove}
                    lastMove={lastMove}
                  />
                  
                  {/* Game Controls */}
                  <div className="flex justify-center gap-4">
                    <Button
                      onClick={handleResign}
                      variant="outline"
                      className="border-red-500/30 text-red-400 hover:bg-red-500/20"
                    >
                      <Flag className="w-4 h-4 mr-2" />
                      Resign
                    </Button>
                    <Button
                      onClick={handleOfferDraw}
                      variant="outline"
                      className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/20"
                    >
                      <Handshake className="w-4 h-4 mr-2" />
                      Offer Draw
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Game Info Sidebar */}
              <div className="w-80 bg-slate-800/30 backdrop-blur-xl border-l border-purple-500/20 p-6 overflow-y-auto custom-scrollbar">
                {/* Player Info */}
                <div className="space-y-4 mb-6">
                  <Card className="glass-effect">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-medium">Opponent</div>
                          <div className="text-xs text-gray-400">Rating: 1420</div>
                        </div>
                      </div>
                      <div className="text-sm text-gray-400">
                        Playing as {playerColor === 'w' ? 'Black' : 'White'}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="glass-effect border-purple-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                          <Trophy className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-medium">You</div>
                          <div className="text-xs text-gray-400">Rating: {currentUser?.rating}</div>
                        </div>
                      </div>
                      <div className="text-sm text-purple-400">
                        Playing as {playerColor === 'w' ? 'White' : 'Black'}
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Move History */}
                <Card className="mb-6">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-purple-400" />
                      Move History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-slate-900/50 rounded-lg p-3 h-40 overflow-y-auto custom-scrollbar">
                      <div className="space-y-1">
                        {renderMoveHistory()}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Betting Info */}
                {currentGame && (
                  <Card className="glass-effect">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Coins className="w-4 h-4 text-cyan-400" />
                        Betting Info
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Your Bet:</span>
                          <span className="font-bold text-green-400">{currentGame.betAmount} SOL</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Opponent Bet:</span>
                          <span className="font-bold text-green-400">{currentGame.betAmount} SOL</span>
                        </div>
                        <Separator className="border-purple-500/20" />
                        <div className="flex justify-between">
                          <span className="text-gray-400">Total Pot:</span>
                          <span className="font-bold text-cyan-400 text-lg">{currentGame.potAmount} SOL</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </>
          )}
        </div>
      </div>
      
      {/* Modals */}
      <DepositModal
        isOpen={showDepositModal}
        onClose={() => setShowDepositModal(false)}
        userId={currentUser?.id || null}
        currentBalance={currentUser?.gameBalance || '0'}
      />
      
      <WithdrawModal
        isOpen={showWithdrawModal}
        onClose={() => setShowWithdrawModal(false)}
        userId={currentUser?.id || null}
        currentBalance={currentUser?.gameBalance || '0'}
        walletAddress={publicKey}
      />
    </div>
  );
}
