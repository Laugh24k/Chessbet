import { users, games, transactions, type User, type InsertUser, type Game, type InsertGame, type Transaction, type InsertTransaction } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, newBalance: string): Promise<User | undefined>;
  updateUserStats(userId: number, wins: number, losses: number, rating: number): Promise<User | undefined>;

  // Game methods
  getGame(id: number): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  updateGame(id: number, updates: Partial<Game>): Promise<Game | undefined>;
  getActiveGames(): Promise<Game[]>;
  getWaitingGames(): Promise<Game[]>;
  getUserGames(userId: number): Promise<Game[]>;

  // Transaction methods
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getUserTransactions(userId: number): Promise<Transaction[]>;
  updateTransactionStatus(id: number, status: string, txHash?: string): Promise<Transaction | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, newBalance: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ gameBalance: newBalance })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async updateUserStats(userId: string, wins: number, losses: number, rating: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ wins, losses, rating })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async updateUserProfile(userId: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  // Game operations
  async getGame(id: number): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game || undefined;
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const [game] = await db
      .insert(games)
      .values(insertGame)
      .returning();
    return game;
  }

  async updateGame(id: number, updates: Partial<Game>): Promise<Game | undefined> {
    const [game] = await db
      .update(games)
      .set(updates)
      .where(eq(games.id, id))
      .returning();
    return game || undefined;
  }

  async getActiveGames(): Promise<Game[]> {
    return await db.select().from(games).where(eq(games.status, 'active'));
  }

  async getWaitingGames(): Promise<Game[]> {
    return await db.select().from(games).where(eq(games.status, 'waiting'));
  }

  async getGamesByRating(minRating: number, maxRating: number): Promise<Game[]> {
    // This would require joining with users table to filter by rating
    return await db.select().from(games).where(eq(games.status, 'waiting'));
  }

  async getUserGames(userId: string): Promise<Game[]> {
    return await db.select().from(games).where(
      sql`white_player_id = ${userId} OR black_player_id = ${userId}`
    );
  }

  // Transaction operations
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async updateTransactionStatus(id: number, status: string, txHash?: string): Promise<Transaction | undefined> {
    const [transaction] = await db
      .update(transactions)
      .set({ status, ...(txHash && { txHash }) })
      .where(eq(transactions.id, id))
      .returning();
    return transaction || undefined;
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private games: Map<number, Game>;
  private transactions: Map<number, Transaction>;
  private currentUserId: number;
  private currentGameId: number;
  private currentTransactionId: number;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.transactions = new Map();
    this.currentUserId = 1;
    this.currentGameId = 1;
    this.currentTransactionId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === walletAddress,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
      gameBalance: insertUser.gameBalance || "0",
      wins: insertUser.wins || 0,
      losses: insertUser.losses || 0,
      rating: insertUser.rating || 1200,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(userId: number, newBalance: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      const updatedUser = { ...user, gameBalance: newBalance };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async updateUserStats(userId: number, wins: number, losses: number, rating: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      const updatedUser = { ...user, wins, losses, rating };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  // Game methods
  async getGame(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = this.currentGameId++;
    const game: Game = {
      ...insertGame,
      id,
      createdAt: new Date(),
      completedAt: null,
      gameState: insertGame.gameState || "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      moveHistory: insertGame.moveHistory || [],
      status: insertGame.status || "waiting",
      currentTurn: insertGame.currentTurn || "white",
      whiteTimeRemaining: insertGame.whiteTimeRemaining || 600,
      blackTimeRemaining: insertGame.blackTimeRemaining || 600,
    };
    this.games.set(id, game);
    return game;
  }

  async updateGame(id: number, updates: Partial<Game>): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (game) {
      const updatedGame = { ...game, ...updates };
      this.games.set(id, updatedGame);
      return updatedGame;
    }
    return undefined;
  }

  async getActiveGames(): Promise<Game[]> {
    return Array.from(this.games.values()).filter(game => game.status === "active");
  }

  async getWaitingGames(): Promise<Game[]> {
    return Array.from(this.games.values()).filter(game => game.status === "waiting");
  }

  async getUserGames(userId: number): Promise<Game[]> {
    return Array.from(this.games.values()).filter(
      game => game.whitePlayerId === userId || game.blackPlayerId === userId
    );
  }

  // Transaction methods
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      createdAt: new Date(),
      status: insertTransaction.status || "pending",
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getUserTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      transaction => transaction.userId === userId
    );
  }

  async updateTransactionStatus(id: number, status: string, txHash?: string): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (transaction) {
      const updatedTransaction = { ...transaction, status, txHash: txHash || transaction.txHash };
      this.transactions.set(id, updatedTransaction);
      return updatedTransaction;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
