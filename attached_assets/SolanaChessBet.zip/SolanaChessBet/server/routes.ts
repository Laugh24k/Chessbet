import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertUserSchema, insertGameSchema, insertTransactionSchema } from "@shared/schema";
import { Chess } from "chess.js";

interface GameSession {
  gameId: number;
  whitePlayer?: WebSocket;
  blackPlayer?: WebSocket;
  chess: Chess;
  lastActivity: number;
}

const gameSessions = new Map<number, GameSession>();

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time game communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');

    ws.on('message', async (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        await handleWebSocketMessage(ws, message);
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid message format' }));
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      handlePlayerDisconnect(ws);
    });
  });

  // User routes
  app.post('/api/users', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByWalletAddress(userData.walletAddress);
      if (existingUser) {
        return res.json(existingUser);
      }

      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : 'Invalid user data' });
    }
  });

  app.get('/api/users/:walletAddress', async (req, res) => {
    try {
      const user = await storage.getUserByWalletAddress(req.params.walletAddress);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user' });
    }
  });

  // Transaction routes
  app.post('/api/transactions', async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(transactionData);
      
      // For MVP, simulate transaction processing
      if (transactionData.type === 'deposit') {
        const user = await storage.getUser(transactionData.userId);
        if (user) {
          const newBalance = (parseFloat(user.gameBalance) + parseFloat(transactionData.amount)).toString();
          await storage.updateUserBalance(transactionData.userId, newBalance);
          await storage.updateTransactionStatus(transaction.id, 'completed');
        }
      } else if (transactionData.type === 'withdraw') {
        const user = await storage.getUser(transactionData.userId);
        if (user && parseFloat(user.gameBalance) >= parseFloat(transactionData.amount)) {
          const newBalance = (parseFloat(user.gameBalance) - parseFloat(transactionData.amount)).toString();
          await storage.updateUserBalance(transactionData.userId, newBalance);
          await storage.updateTransactionStatus(transaction.id, 'completed');
        } else {
          await storage.updateTransactionStatus(transaction.id, 'failed');
        }
      }

      res.json(transaction);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : 'Invalid transaction data' });
    }
  });

  app.get('/api/transactions/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const transactions = await storage.getUserTransactions(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch transactions' });
    }
  });

  // Game routes
  app.post('/api/games', async (req, res) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      
      // Check if white player has sufficient balance
      const whitePlayer = await storage.getUser(gameData.whitePlayerId!);
      if (!whitePlayer) {
        return res.status(400).json({ message: 'Player not found' });
      }

      const betAmount = parseFloat(gameData.betAmount);
      const currentBalance = parseFloat(whitePlayer.gameBalance);

      if (currentBalance < betAmount) {
        return res.status(400).json({ message: 'Insufficient balance' });
      }

      // Deduct bet amount from white player's balance
      const newBalance = (currentBalance - betAmount).toString();
      await storage.updateUserBalance(whitePlayer.id, newBalance);

      // Create the game
      const game = await storage.createGame(gameData);
      
      // Create game session
      const chess = new Chess();
      gameSessions.set(game.id, {
        gameId: game.id,
        chess,
        lastActivity: Date.now(),
      });

      res.json(game);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : 'Invalid game data' });
    }
  });

  app.get('/api/games/waiting', async (req, res) => {
    try {
      const games = await storage.getWaitingGames();
      res.json(games);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch waiting games' });
    }
  });

  app.get('/api/games/:id', async (req, res) => {
    try {
      const gameId = parseInt(req.params.id);
      const game = await storage.getGame(gameId);
      if (!game) {
        return res.status(404).json({ message: 'Game not found' });
      }
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch game' });
    }
  });

  app.post('/api/games/:id/join', async (req, res) => {
    try {
      const gameId = parseInt(req.params.id);
      const { userId } = req.body;

      const game = await storage.getGame(gameId);
      if (!game || game.status !== 'waiting') {
        return res.status(400).json({ message: 'Game not available' });
      }

      // Check if black player has sufficient balance
      const blackPlayer = await storage.getUser(userId);
      if (!blackPlayer) {
        return res.status(400).json({ message: 'Player not found' });
      }

      const betAmount = parseFloat(game.betAmount);
      const currentBalance = parseFloat(blackPlayer.gameBalance);

      if (currentBalance < betAmount) {
        return res.status(400).json({ message: 'Insufficient balance' });
      }

      // Deduct bet amount from black player's balance
      const newBalance = (currentBalance - betAmount).toString();
      await storage.updateUserBalance(blackPlayer.id, newBalance);

      const updatedGame = await storage.updateGame(gameId, {
        blackPlayerId: userId,
        status: 'active',
      });

      res.json(updatedGame);
    } catch (error) {
      res.status(500).json({ message: 'Failed to join game' });
    }
  });

  async function handleWebSocketMessage(ws: WebSocket, message: any) {
    const { type, gameId, userId, data } = message;

    switch (type) {
      case 'join_game':
        await handleJoinGame(ws, gameId, userId);
        break;
      case 'make_move':
        await handleMakeMove(ws, gameId, userId, data);
        break;
      case 'chat_message':
        await handleChatMessage(ws, gameId, userId, data);
        break;
      case 'resign_game':
        await handleResignGame(ws, gameId, userId);
        break;
      default:
        ws.send(JSON.stringify({ type: 'error', message: 'Unknown message type' }));
    }
  }

  async function handleJoinGame(ws: WebSocket, gameId: number, userId: number) {
    const session = gameSessions.get(gameId);
    const game = await storage.getGame(gameId);

    if (!session || !game) {
      ws.send(JSON.stringify({ type: 'error', message: 'Game not found' }));
      return;
    }

    if (game.whitePlayerId === userId) {
      session.whitePlayer = ws;
    } else if (game.blackPlayerId === userId) {
      session.blackPlayer = ws;
    } else {
      ws.send(JSON.stringify({ type: 'error', message: 'Not authorized for this game' }));
      return;
    }

    session.lastActivity = Date.now();

    // Send current game state
    ws.send(JSON.stringify({
      type: 'game_state',
      gameId,
      fen: session.chess.fen(),
      turn: session.chess.turn(),
      moveHistory: session.chess.history(),
      gameStatus: game.status,
    }));

    // Notify both players if game is ready
    if (session.whitePlayer && session.blackPlayer && game.status === 'active') {
      const readyMessage = {
        type: 'game_ready',
        gameId,
        whitePlayer: game.whitePlayerId,
        blackPlayer: game.blackPlayerId,
      };

      if (session.whitePlayer.readyState === WebSocket.OPEN) {
        session.whitePlayer.send(JSON.stringify(readyMessage));
      }
      if (session.blackPlayer.readyState === WebSocket.OPEN) {
        session.blackPlayer.send(JSON.stringify(readyMessage));
      }
    }
  }

  async function handleMakeMove(ws: WebSocket, gameId: number, userId: number, moveData: any) {
    const session = gameSessions.get(gameId);
    const game = await storage.getGame(gameId);

    if (!session || !game) {
      ws.send(JSON.stringify({ type: 'error', message: 'Game not found' }));
      return;
    }

    // Validate player turn
    const isWhitePlayer = game.whitePlayerId === userId;
    const isBlackPlayer = game.blackPlayerId === userId;
    const currentTurn = session.chess.turn();

    if (!isWhitePlayer && !isBlackPlayer) {
      ws.send(JSON.stringify({ type: 'error', message: 'Not authorized for this game' }));
      return;
    }

    if ((currentTurn === 'w' && !isWhitePlayer) || (currentTurn === 'b' && !isBlackPlayer)) {
      ws.send(JSON.stringify({ type: 'error', message: 'Not your turn' }));
      return;
    }

    try {
      const move = session.chess.move(moveData);
      if (!move) {
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid move' }));
        return;
      }

      session.lastActivity = Date.now();

      // Update game in storage
      const updatedGame = await storage.updateGame(gameId, {
        gameState: session.chess.fen(),
        moveHistory: session.chess.history(),
        currentTurn: session.chess.turn() === 'w' ? 'white' : 'black',
      });

      // Check for game end
      let gameResult = null;
      if (session.chess.isGameOver()) {
        if (session.chess.isCheckmate()) {
          gameResult = session.chess.turn() === 'w' ? 'black' : 'white';
        } else {
          gameResult = 'draw';
        }

        await storage.updateGame(gameId, {
          status: 'completed',
          winner: gameResult,
          completedAt: new Date(),
        });

        // Handle pot distribution
        await handleGameCompletion(gameId, gameResult);
      }

      // Broadcast move to both players
      const moveMessage = {
        type: 'move_made',
        gameId,
        move: move,
        fen: session.chess.fen(),
        turn: session.chess.turn(),
        gameResult,
      };

      if (session.whitePlayer && session.whitePlayer.readyState === WebSocket.OPEN) {
        session.whitePlayer.send(JSON.stringify(moveMessage));
      }
      if (session.blackPlayer && session.blackPlayer.readyState === WebSocket.OPEN) {
        session.blackPlayer.send(JSON.stringify(moveMessage));
      }

    } catch (error) {
      ws.send(JSON.stringify({ type: 'error', message: 'Failed to make move' }));
    }
  }

  async function handleChatMessage(ws: WebSocket, gameId: number, userId: number, message: string) {
    const session = gameSessions.get(gameId);
    if (!session) return;

    const chatMessage = {
      type: 'chat_message',
      gameId,
      userId,
      message,
      timestamp: Date.now(),
    };

    if (session.whitePlayer && session.whitePlayer.readyState === WebSocket.OPEN) {
      session.whitePlayer.send(JSON.stringify(chatMessage));
    }
    if (session.blackPlayer && session.blackPlayer.readyState === WebSocket.OPEN) {
      session.blackPlayer.send(JSON.stringify(chatMessage));
    }
  }

  async function handleGameCompletion(gameId: number, result: string | null) {
    const game = await storage.getGame(gameId);
    if (!game) return;

    if (result === 'white' && game.whitePlayerId) {
      // White wins - transfer pot to white player
      const whitePlayer = await storage.getUser(game.whitePlayerId);
      if (whitePlayer) {
        const newBalance = (parseFloat(whitePlayer.gameBalance) + parseFloat(game.potAmount)).toString();
        await storage.updateUserBalance(game.whitePlayerId, newBalance);
        await storage.updateUserStats(game.whitePlayerId, whitePlayer.wins + 1, whitePlayer.losses, whitePlayer.rating + 20);
      }
      
      if (game.blackPlayerId) {
        const blackPlayer = await storage.getUser(game.blackPlayerId);
        if (blackPlayer) {
          await storage.updateUserStats(game.blackPlayerId, blackPlayer.wins, blackPlayer.losses + 1, Math.max(blackPlayer.rating - 20, 100));
        }
      }
    } else if (result === 'black' && game.blackPlayerId) {
      // Black wins - transfer pot to black player
      const blackPlayer = await storage.getUser(game.blackPlayerId);
      if (blackPlayer) {
        const newBalance = (parseFloat(blackPlayer.gameBalance) + parseFloat(game.potAmount)).toString();
        await storage.updateUserBalance(game.blackPlayerId, newBalance);
        await storage.updateUserStats(game.blackPlayerId, blackPlayer.wins + 1, blackPlayer.losses, blackPlayer.rating + 20);
      }

      if (game.whitePlayerId) {
        const whitePlayer = await storage.getUser(game.whitePlayerId);
        if (whitePlayer) {
          await storage.updateUserStats(game.whitePlayerId, whitePlayer.wins, whitePlayer.losses + 1, Math.max(whitePlayer.rating - 20, 100));
        }
      }
    } else if (result === 'draw') {
      // Draw - refund both players
      if (game.whitePlayerId) {
        const whitePlayer = await storage.getUser(game.whitePlayerId);
        if (whitePlayer) {
          const refund = parseFloat(game.betAmount);
          const newBalance = (parseFloat(whitePlayer.gameBalance) + refund).toString();
          await storage.updateUserBalance(game.whitePlayerId, newBalance);
        }
      }

      if (game.blackPlayerId) {
        const blackPlayer = await storage.getUser(game.blackPlayerId);
        if (blackPlayer) {
          const refund = parseFloat(game.betAmount);
          const newBalance = (parseFloat(blackPlayer.gameBalance) + refund).toString();
          await storage.updateUserBalance(game.blackPlayerId, newBalance);
        }
      }
    }
  }

  async function handleResignGame(ws: WebSocket, gameId: number, userId: number) {
    const session = gameSessions.get(gameId);
    const game = await storage.getGame(gameId);

    if (!session || !game) {
      ws.send(JSON.stringify({ type: 'error', message: 'Game not found' }));
      return;
    }

    // Validate player is in this game
    const isWhitePlayer = game.whitePlayerId === userId;
    const isBlackPlayer = game.blackPlayerId === userId;

    if (!isWhitePlayer && !isBlackPlayer) {
      ws.send(JSON.stringify({ type: 'error', message: 'Not authorized for this game' }));
      return;
    }

    // Determine winner (opponent of resigning player)
    const winner = isWhitePlayer ? 'black' : 'white';

    // Update game in storage
    await storage.updateGame(gameId, {
      status: 'completed',
      winner: winner,
      completedAt: new Date(),
    });

    // Handle pot distribution
    await handleGameCompletion(gameId, winner);

    // Notify both players
    const resignMessage = {
      type: 'game_resigned',
      gameId,
      resignedPlayer: userId,
      winner: winner,
      reason: 'resignation'
    };

    if (session.whitePlayer && session.whitePlayer.readyState === WebSocket.OPEN) {
      session.whitePlayer.send(JSON.stringify(resignMessage));
    }
    if (session.blackPlayer && session.blackPlayer.readyState === WebSocket.OPEN) {
      session.blackPlayer.send(JSON.stringify(resignMessage));
    }

    // Clean up game session
    gameSessions.delete(gameId);
  }

  function handlePlayerDisconnect(ws: WebSocket) {
    for (const [gameId, session] of gameSessions.entries()) {
      if (session.whitePlayer === ws) {
        session.whitePlayer = undefined;
      } else if (session.blackPlayer === ws) {
        session.blackPlayer = undefined;
      }
    }
  }

  // Clean up inactive game sessions
  setInterval(() => {
    const now = Date.now();
    for (const [gameId, session] of gameSessions.entries()) {
      if (now - session.lastActivity > 30 * 60 * 1000) { // 30 minutes
        gameSessions.delete(gameId);
        storage.updateGame(gameId, { status: 'abandoned' });
      }
    }
  }, 5 * 60 * 1000); // Check every 5 minutes

  return httpServer;
}
