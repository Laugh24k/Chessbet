import { pgTable, text, serial, integer, boolean, timestamp, decimal, varchar, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Privy auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(), // Privy user ID
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  username: varchar("username", { length: 50 }).unique(),
  walletAddress: text("wallet_address").unique(),
  gameBalance: decimal("game_balance", { precision: 18, scale: 9 }).notNull().default("0"),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  rating: integer("rating").notNull().default(1200),
  skillLevel: varchar("skill_level", { length: 50 }), // "new", "beginner", "intermediate", "advanced"
  chessComUsername: varchar("chess_com_username", { length: 50 }),
  chessComRating: integer("chess_com_rating"),
  hasCompletedProfile: boolean("has_completed_profile").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  whitePlayerId: varchar("white_player_id").references(() => users.id),
  blackPlayerId: varchar("black_player_id").references(() => users.id),
  betAmount: decimal("bet_amount", { precision: 18, scale: 9 }).notNull(),
  potAmount: decimal("pot_amount", { precision: 18, scale: 9 }).notNull(),
  gameState: text("game_state").notNull(), // FEN notation
  moveHistory: text("move_history").array().notNull().default([]),
  status: text("status").notNull().default("waiting"), // waiting, active, completed, abandoned
  winner: text("winner"), // white, black, draw, null
  timeControl: text("time_control").notNull().default("10+0"),
  whiteTimeRemaining: integer("white_time_remaining").notNull().default(600), // seconds
  blackTimeRemaining: integer("black_time_remaining").notNull().default(600), // seconds
  currentTurn: text("current_turn").notNull().default("white"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // deposit, withdraw, bet, win
  amount: decimal("amount", { precision: 18, scale: 9 }).notNull(),
  txHash: text("tx_hash"),
  status: text("status").notNull().default("pending"), // pending, completed, failed
  gameId: integer("game_id").references(() => games.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = typeof users.$inferInsert;
export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
